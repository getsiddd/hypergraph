{
	title: '',
	$date_value: '2016-12-22',
	$date_type: 'date',
	date: 'Thursday, 22 December, 2016',
	published: false,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '',
		contents: []
	},
	teaser: {
		doc: '',
		$image_type: 'image',
		image: '',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '',
			contents: []
		}
	},
	meta: {
		last_edited: 1501680325
	}
}