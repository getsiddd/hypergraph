{
	title: '',
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '',
	$marked_doc_hidden: true,
	marked_doc: '',
	contents: [],
	$contents_hidden: true,
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '',
		contents: []
	},
	meta: {
		last_edited: 1501680325
	}
}