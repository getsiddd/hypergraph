{
	users: [
		{
			username: 'gottwik',
			salt: 'b0306f9e001d084bbf0c8888618b30ef',
			hash: '18f39fb5e2cf83229d8a2fe644fda17ab8bd4907a4354cc182454ed9bb0269b3',
			user_created_timestamp: 1470054375378
		},
		{
			username: 'admin',
			tags: [],
			salt: 'e0874b11e723c2736c103d1f9bef37c6',
			hash: 'fb8e083df18f54bb4a54daca253fba87570282caef17baa8a490bd39296ac0ff',
			user_created_timestamp: 1510607433264
		}
	],
	meta: {
		last_edited: 1510607433
	}
}