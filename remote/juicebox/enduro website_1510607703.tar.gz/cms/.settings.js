{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1485265097_Wallpaper-Sunset-Winter.jpg',
		dark: true
	}
}